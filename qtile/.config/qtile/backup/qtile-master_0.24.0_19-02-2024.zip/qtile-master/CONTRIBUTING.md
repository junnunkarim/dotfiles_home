# How to contribute

Instead of making this document a copy of [the _contributing_ section of our
documentation](https://docs.qtile.org/en/latest/manual/contributing.html),
we just link to it here.
