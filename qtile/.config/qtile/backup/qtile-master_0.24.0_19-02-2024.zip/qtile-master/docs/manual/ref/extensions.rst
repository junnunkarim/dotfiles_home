===================
Built-in Extensions
===================

.. qtile_module:: libqtile.extension
    :baseclass: libqtile.extension.base._Extension
    :no-commands:
