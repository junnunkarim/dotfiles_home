.. _qtile-start:

===========
qtile start
===========

This is the entry point for the window manager, and what you should run from
your ``.xsession`` or similar. This will make an attempt to detect if qtile is
already running and fail if it is. See ``qtile start --help`` for more details.
