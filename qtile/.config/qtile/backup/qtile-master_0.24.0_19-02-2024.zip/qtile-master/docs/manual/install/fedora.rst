====================
Installing on Fedora
====================

Stable versions of Qtile are not currently packaged for the current version of Fedora. Users are advised to follow the instructions of :ref:`installing-from-source`.
