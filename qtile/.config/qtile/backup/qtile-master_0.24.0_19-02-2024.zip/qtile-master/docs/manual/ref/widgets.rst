.. _ref-widgets:

================
Built-in Widgets
================

.. qtile_module:: libqtile.widget
    :baseclass: libqtile.widget.base._Widget
    :exclude: Mirror
