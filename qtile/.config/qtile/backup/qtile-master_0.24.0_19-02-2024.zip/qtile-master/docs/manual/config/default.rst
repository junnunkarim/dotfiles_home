.. _default_config:

===================
Default Config File
===================

The below default config file is included with the Qtile package and will
be copied to your home config folder (~/.config/qtile/config.py) if no
config file exists when you start Qtile for the first time.

.. literalinclude:: ../../../libqtile/resources/default_config.py
