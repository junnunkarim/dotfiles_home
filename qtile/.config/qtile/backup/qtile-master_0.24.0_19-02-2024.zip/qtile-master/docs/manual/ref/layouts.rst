.. _ref-layouts:

================
Built-in Layouts
================

.. qtile_module:: libqtile.layout
    :baseclass: libqtile.layout.base.Layout
