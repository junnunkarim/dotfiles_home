=======================
Installing on FreeBSD
=======================

Qtile is available via `FreeBSD Ports
<https://www.freshports.org/x11-wm/qtile/>`_. It can be installed with

.. code-block:: bash

   pkg install qtile

