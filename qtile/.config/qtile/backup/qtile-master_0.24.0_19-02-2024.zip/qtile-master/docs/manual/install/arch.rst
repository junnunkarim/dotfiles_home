========================
Installing on Arch Linux
========================

Stable versions of Qtile are currently packaged for Arch Linux. To install this package, run:

.. code-block:: bash

    pacman -S qtile

Please see the ArchWiki for more information on `Qtile`_.

.. _Qtile: https://wiki.archlinux.org/index.php/Qtile
