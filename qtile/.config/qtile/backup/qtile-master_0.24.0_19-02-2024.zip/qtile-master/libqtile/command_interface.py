from libqtile.command.interface import *  # noqa
from libqtile.log_utils import logger

logger.warning(
    "libqtile.command_interface is deprecated. It has been moved to libqtile.command.interface"
)
