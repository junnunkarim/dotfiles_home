from libqtile.command.client import *  # noqa
from libqtile.log_utils import logger

logger.warning(
    "libqtile.command_client is deprecated. It has been moved to libqtile.command.client"
)
