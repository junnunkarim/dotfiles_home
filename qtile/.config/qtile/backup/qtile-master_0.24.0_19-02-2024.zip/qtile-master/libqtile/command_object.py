from libqtile.command.base import *  # noqa
from libqtile.log_utils import logger

logger.warning(
    "libqtile.command_object is deprecated. It has been moved to libqtile.command.base."
)
