from libqtile.command.graph import *  # noqa
from libqtile.log_utils import logger

logger.warning(
    "libqtile.command_graph is deprecated. It has been moved to libqtile.command.graph"
)
