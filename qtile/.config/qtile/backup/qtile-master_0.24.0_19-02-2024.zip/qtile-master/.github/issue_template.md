Are you a Qtile maintainer, or someone who has been explicitly asked by a maintainer to open an issue without using the bug report template?

If not, you shouldn't be here. Go back to the previous page and click another button, or… expose yourself to the Python's bite.
