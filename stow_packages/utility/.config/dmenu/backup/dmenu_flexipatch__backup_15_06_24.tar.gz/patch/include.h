#if DYNAMIC_OPTIONS_PATCH
#include "dynamicoptions.h"
#endif
#if FZFEXPECT_PATCH
#include "fzfexpect.h"
#endif
#if MULTI_SELECTION_PATCH
#include "multiselect.h"
#endif
#if HIGHPRIORITY_PATCH
#include "highpriority.h"
#endif
#if NON_BLOCKING_STDIN_PATCH
#include "nonblockingstdin.h"
#endif
#if NUMBERS_PATCH
#include "numbers.h"
#endif
