static void expect(char *expect, XKeyEvent *ev);
