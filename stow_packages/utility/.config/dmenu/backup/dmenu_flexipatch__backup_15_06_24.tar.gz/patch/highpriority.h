static int arrayhas(char **list, int length, char *item);

