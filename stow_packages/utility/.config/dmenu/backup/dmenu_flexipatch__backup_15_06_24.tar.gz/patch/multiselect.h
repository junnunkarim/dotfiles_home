static int issel(size_t id);
