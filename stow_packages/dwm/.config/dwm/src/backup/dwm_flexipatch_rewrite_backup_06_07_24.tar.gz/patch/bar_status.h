static int width_status(Bar *bar, BarArg *a);
static int draw_status(Bar *bar, BarArg *a);
static int click_status(Bar *bar, Arg *arg, BarArg *a);

