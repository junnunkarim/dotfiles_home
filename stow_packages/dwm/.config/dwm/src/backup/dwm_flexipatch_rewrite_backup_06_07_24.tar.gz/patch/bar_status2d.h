static int width_status2d(Bar *bar, BarArg *a);
static int draw_status2d(Bar *bar, BarArg *a);
static int click_status2d(Bar *bar, Arg *arg, BarArg *a);
static int drawstatusbar(BarArg *a, char *text);
static int status2dtextlength(char *stext);

