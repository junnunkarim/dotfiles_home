static void placedir(const Arg *arg);
