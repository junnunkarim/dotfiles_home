#include <time.h>

static void drawalttab(int nwins, int first, Monitor *m);
static void alttabstart(const Arg *arg);
static void alttabend();
