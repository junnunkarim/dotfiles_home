static void tagall(const Arg *arg);

