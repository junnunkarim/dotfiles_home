enum {
	DEFAULT_TAGS,
	ALTERNATIVE_TAGS,
	ALT_TAGS_DECORATION,
};

static char * tagicon(Monitor *m, int tag);

