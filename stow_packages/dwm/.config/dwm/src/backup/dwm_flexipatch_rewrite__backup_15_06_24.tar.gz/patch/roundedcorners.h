static void drawroundedcorners(Client *c);

