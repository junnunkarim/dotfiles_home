static void togglesticky(const Arg *arg);

