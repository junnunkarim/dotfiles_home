static void distributetags(const Arg *arg);

