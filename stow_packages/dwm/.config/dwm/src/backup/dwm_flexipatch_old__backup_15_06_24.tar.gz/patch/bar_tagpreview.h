static void showtagpreview(int tag, int x, int y);
static void hidetagpreview(Monitor *m);
static void tagpreviewswitchtag(void);
static void updatepreview(void);
